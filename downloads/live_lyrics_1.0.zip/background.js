var client_id = "74a4cbcd4f4b4d328707f67058516c69";
var client_secret =  "d37ded8c31e342c9841fd6542b3b5969";
var redirectUri = chrome.identity.getRedirectURL();
var scopes = "user-read-playback-state";
var authRunning;

document.addEventListener('DOMContentLoaded', function() {
  var button = document.getElementById("toggle");
  var text = document.getElementById("song");
  var check = document.getElementById("check");

  //Checking if Lyrics is running, setting CSS settings
  chrome.storage.local.get(["active"], function(items){
    if (items['active']) {
      button.className = "on";
      button.innerHTML = "Live Lyrics is activated!<br>Click to stop!";
      text.innerHTML = "Live Lyrics";
    }
    else{
      button.className = "off";
      button.innerHTML = "Live Lyrics is deactivated!<br>Click to start!";
    }
  });

  //Toggle Lyrics Running state
  button.addEventListener('click', function() {
    //Checking which state button currently is in, and changing it
    chrome.storage.local.get(["active"], function(items){
      if (items['active']) {
        chrome.storage.local.set({ "active": false });
        button.className = "off";
        button.innerHTML = "Live Lyrics is deactivated!<br>Click to start!";
      }
      else{
        chrome.storage.local.set({ "active": true });
        button.className = "on";
        button.innerHTML = "Live Lyrics is activated!<br>Click to stop!";
        text.innerHTML = "Live Lyrics";
      }
    });
  });

  //Handeling Amazon Support Services
  chrome.storage.local.get(["support"], function(items){
    check.checked = items['support'];
  });
  //Toggle Support
  check.addEventListener('click', function() {
    chrome.storage.local.set({ "support": check.checked });
  });
});

//Update Function, performing every 2 seconds
setInterval(function(){
  chrome.storage.local.get(["active"], function(items){
    if (items['active']) {
      //chrome.storage.local.get(["authCode"], function(items){getTitle(items.authCode);});
      startAuthentification();
    }
  });
}, 2000);


//Starting Authentification proccess if one isn't already running
function startAuthentification(){
  //Checking if already logged in
  chrome.storage.local.get(["authCode"], function callback(key){
    //If 'authCode' isn't stored locally, reauth
    if (key['authCode'] != undefined){
      //'authCode' is defined -> authCode is available
      chrome.storage.local.get(["authCode"], function(items){getTitle(items['authCode']);});
    }
    else{
      //'authCode' isn't defined -> authCode not available
      if (!authRunning){
        auth();
        authRunning = true;
      }
      chrome.storage.local.get(["authCode"], function(items){getTitle(items['authCode']);});
    }
  });
}

//Authentification with Spotify
function auth(){
  chrome.identity.launchWebAuthFlow({
    "url": "https://accounts.spotify.com/authorize?client_id="+client_id+
    "&redirect_uri="+ encodeURIComponent(redirectUri) +
    "&response_type=code"+
    "&scope=" + encodeURIComponent(scopes),
    "interactive": true
  },
  function(redirect_url) {
    authRunning = false;
    var url = new URL(redirect_url);
    code = url.searchParams.get("code");
    //GETTING AUTHCODE
    getToken(code);
  });
}

//Getting AuthCode
function getToken(code){
  $.ajax({
    method: "POST",
    url: "https://accounts.spotify.com/api/token",
    data: {
      "grant_type":    "authorization_code",
      "code":          code,
      "redirect_uri":  redirectUri,
      "client_secret": client_secret,
      "client_id":     client_id,
    },
    success: function (result){
      accessToken = result['access_token'];
      chrome.storage.local.set({ "authCode": accessToken });
    }
  });
}

//Gathering Userdata, cheking if authentification is up-to-date
function getTitle(authCode) {
  var titleContainer = document.getElementById("song");
  //Collecting user Data from Spotify Servers
  spotifyData = $.ajax({
      url: 'https://api.spotify.com/v1/me/player/currently-playing',
      headers: {
         'Authorization': 'Bearer ' + authCode  //Accesstoken nicht definiert
      }
  });

  //Checking if authentification is still working
  if(spotifyData.hasOwnProperty("status")){
    //Authotization successful
  }
  else{
    //Authentification is expired
    if (!authRunning){
      auth();
      authRunning = true;
    }
  }
  //Starts process of getting the Title
  spotifyData.then(
    function(spotifyData) {
      //Getting Songtitle and Artist out of Object
      item = spotifyData.item;
      artist = item.artists[0].name;
      song = item.name;
      //Stripping Title Additions that could interfear with the lyric search
      var array = song.split(' (');
      song2 = array[0];
      var array = song2.split(' -');
      title = array[0] + " " + artist;
      //if Title Container is empty, set it
      if (titleContainer == null){
        getLyrics(title);
      }else{
        if (titleContainer.innerHTML == title) {
          //Title Container is set already; Getting Lyrics
          getLyrics(title);
        }
        else{
          //Updating Title Container
          titleContainer.innerHTML = title;
          getLyrics(title);
          //Starting the automatic lyric detection
          chrome.storage.local.set({ "active": true });
        }
      }
    }
  );
}

//Getting Lyrics from Genius
function getLyrics(title){
  var request = new XMLHttpRequest();
  request.open("GET","https://api.genius.com/search?q=" + encodeURIComponent(title));
  request.setRequestHeader("Authorization","Bearer AUMB5hUHKcw9LlsmBGuSzioC-CMEvbrA6k36nSaa7LxeEcTMZeqknLeLjY8wQgAd");
  request.addEventListener('load', function(event) {
     if (request.status >= 200 && request.status < 300) {
       response = request['response'];
       response = JSON.parse(response);
       hits = response['response'];
       hit = hits['hits'];
       song = hit[0];
       song_result = song['result'];
       url = song_result['url'];
       pattern = '*://*.genius.com/*';
       chrome.tabs.query({'url': pattern}, function(callback){
         var callback2 = callback[0];
         //If no Genius Page is Open, a new one will open in a blank tab
          if (callback2 == undefined){
           var win = window.open(url, '_blank');
           win.focus();
         }
         //Updates Genius Page
         if (callback2['url'] != url){
           chrome.tabs.update(callback2['id'], {'url': url});
         }

       })
     } else {
        console.warn(request.statusText, request.responseText);
     }
  });
  request.send();
}
//Authentification Startet scheiße oft
